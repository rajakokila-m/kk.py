
# main.py

import sys

def read_data(file_path):
    with open(file_path, 'r') as f:
        return [float(line.strip()) for line in f if line.strip()]

def calculate_average(data):
    return sum(data) / len(data)

def calculate_std_dev(data, mean):
    return (sum((x - mean) ** 2 for x in data) / len(data)) ** 0.5

def write_results(output_path, average, std_dev):
    with open(output_path, 'w') as f:
        f.write(f"Average: {average:.2f}\n")
        f.write(f"Standard Deviation: {std_dev:.2f}\n")

def main():
    if len(sys.argv) < 2:
        print("Usage: python main.py <input_file>")
        return

    input_file = sys.argv[1]
    output_file = "output.txt"

    try:
        data = read_data(input_file)
        average = calculate_average(data)
        std_dev = calculate_std_dev(data, average)
        write_results(output_file, average, std_dev)
        print("Processing complete. Results saved in output.txt")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
