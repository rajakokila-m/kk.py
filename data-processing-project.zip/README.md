# Data Processing Project

This is a Python-based command line program that reads numerical data from a file, calculates the average and standard deviation, and writes the results to an output file.

## How to Run

1. Save your data in a text file (one number per line).
2. Run the script from command line:

```
python main.py data_input.txt
```

Or use the batch script:

```
run_script.bat data_input.txt
```

## Author

Your Name
